import React from 'react';
import { Equipment } from '../types';

const SAMPLE_EQUIPMENT: Equipment[] = [
  // Electronics
  {
    id: '1',
    name: 'Professional DSLR Camera',
    category: 'electronics',
    description: 'High-end DSLR camera perfect for professional photography',
    price_per_day: 50,
    available: true,
    image_url: 'https://images.unsplash.com/photo-1516035069371-29a1b244cc32'
  },
  {
    id: '2',
    name: '4K Video Camera',
    category: 'electronics',
    description: 'Professional 4K video camera for filmmaking',
    price_per_day: 75,
    available: true,
    image_url: 'https://images.unsplash.com/photo-1589872307627-e08d5c9b6c98'
  },
  
  // Home Appliances
  {
    id: '3',
    name: 'Stand Mixer',
    category: 'home_appliances',
    description: 'Professional grade stand mixer for baking',
    price_per_day: 25,
    available: true,
    image_url: 'https://images.unsplash.com/photo-1594241660363-2c78a8908b45'
  },
  {
    id: '4',
    name: 'Air Fryer Pro',
    category: 'home_appliances',
    description: 'Large capacity air fryer for healthy cooking',
    price_per_day: 15,
    available: true,
    image_url: 'https://images.unsplash.com/photo-1644675348269-e7e5d9a1ff6d'
  },
  {
    id: '5',
    name: 'Robot Vacuum',
    category: 'home_appliances',
    description: 'Smart robot vacuum with mapping technology',
    price_per_day: 20,
    available: true,
    image_url: 'https://images.unsplash.com/photo-1632833239869-a37e3a5806d2'
  },
  
  // Tools
  {
    id: '6',
    name: 'Power Drill Set',
    category: 'tools',
    description: 'Complete power drill set with various bits',
    price_per_day: 20,
    available: true,
    image_url: 'https://images.unsplash.com/photo-1504148455328-c376907d081c'
  },
  {
    id: '7',
    name: 'Pressure Washer',
    category: 'tools',
    description: 'High-pressure washer for outdoor cleaning',
    price_per_day: 35,
    available: true,
    image_url: 'https://images.unsplash.com/photo-1622893288761-5568e4f5fb99'
  },
  {
    id: '8',
    name: 'Table Saw',
    category: 'tools',
    description: 'Professional table saw for woodworking',
    price_per_day: 45,
    available: true,
    image_url: 'https://images.unsplash.com/photo-1504148455328-c376907d081c'
  },
  
  // Sports
  {
    id: '9',
    name: 'Tennis Racket Pro',
    category: 'sports',
    description: 'Professional tennis racket with carrying case',
    price_per_day: 15,
    available: true,
    image_url: 'https://images.unsplash.com/photo-1617083934555-ac7d4fee8718'
  },
  {
    id: '10',
    name: 'Mountain Bike',
    category: 'sports',
    description: 'Full suspension mountain bike for trails',
    price_per_day: 40,
    available: true,
    image_url: 'https://images.unsplash.com/photo-1576435728678-68d0fbf94e91'
  },
  {
    id: '11',
    name: 'Golf Club Set',
    category: 'sports',
    description: 'Complete set of golf clubs with bag',
    price_per_day: 30,
    available: true,
    image_url: 'https://images.unsplash.com/photo-1535131749006-b7f58c99034b'
  }
];

type EquipmentListProps = {
  category?: string;
  searchQuery?: string;
};

export function EquipmentList({ category = 'all', searchQuery = '' }: EquipmentListProps) {
  const filteredEquipment = SAMPLE_EQUIPMENT.filter(item => {
    const matchesCategory = category === 'all' || item.category === category;
    const matchesSearch = item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         item.description.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 p-6">
      {filteredEquipment.map((item) => (
        <div key={item.id} className="bg-white rounded-lg shadow-md overflow-hidden transform transition duration-300 hover:scale-105">
          <div className="relative">
            <img
              src={item.image_url}
              alt={item.name}
              className="w-full h-48 object-cover"
            />
            <span className="absolute top-2 right-2 px-2 py-1 rounded-full text-xs font-semibold bg-white shadow-md">
              {item.category.replace('_', ' ')}
            </span>
          </div>
          <div className="p-4">
            <h3 className="text-lg font-semibold text-gray-900">{item.name}</h3>
            <p className="text-sm text-gray-600 mt-1">{item.description}</p>
            <div className="mt-4 flex justify-between items-center">
              <span className="text-lg font-bold text-indigo-600">
                ${item.price_per_day}/day
              </span>
              <span className={`px-2 py-1 rounded-full text-sm ${
                item.available
                  ? 'bg-green-100 text-green-800'
                  : 'bg-red-100 text-red-800'
              }`}>
                {item.available ? 'Available' : 'Rented'}
              </span>
            </div>
            <button
              className="mt-4 w-full bg-indigo-600 text-white py-2 px-4 rounded-md hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 transition duration-300 ease-in-out transform hover:-translate-y-1"
            >
              Rent Now
            </button>
          </div>
        </div>
      ))}
    </div>
  );
}
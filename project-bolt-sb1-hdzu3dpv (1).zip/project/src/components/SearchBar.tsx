import React, { useState, useEffect } from 'react';
import { Search, Mic } from 'lucide-react';

type SearchBarProps = {
  onSearch: (query: string) => void;
  onCategoryChange: (category: string) => void;
};

export function SearchBar({ onSearch, onCategoryChange }: SearchBarProps) {
  const [query, setQuery] = useState('');
  const [isListening, setIsListening] = useState(false);

  const categories = [
    'all',
    'electronics',
    'home_appliances',
    'tools',
    'sports'
  ];

  const startVoiceSearch = () => {
    if ('webkitSpeechRecognition' in window) {
      const recognition = new webkitSpeechRecognition();
      recognition.continuous = false;
      recognition.interimResults = false;

      recognition.onstart = () => {
        setIsListening(true);
      };

      recognition.onresult = (event) => {
        const transcript = event.results[0][0].transcript;
        setQuery(transcript);
        onSearch(transcript);
      };

      recognition.onend = () => {
        setIsListening(false);
      };

      recognition.start();
    } else {
      alert('Voice search is not supported in your browser.');
    }
  };

  return (
    <div className="max-w-2xl mx-auto p-4 space-y-4">
      <div className="relative">
        <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
          <Search className="h-5 w-5 text-gray-400" />
        </div>
        <input
          type="text"
          className="block w-full pl-10 pr-12 py-2 border border-gray-300 rounded-md leading-5 bg-white placeholder-gray-500 focus:outline-none focus:placeholder-gray-400 focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
          placeholder="Search equipment..."
          value={query}
          onChange={(e) => {
            setQuery(e.target.value);
            onSearch(e.target.value);
          }}
        />
        <button
          onClick={startVoiceSearch}
          className="absolute inset-y-0 right-0 pr-3 flex items-center"
        >
          <Mic className={`h-5 w-5 ${isListening ? 'text-red-500' : 'text-gray-400'}`} />
        </button>
      </div>

      <div className="flex space-x-2 overflow-x-auto pb-2">
        {categories.map((category) => (
          <button
            key={category}
            onClick={() => onCategoryChange(category)}
            className="px-4 py-2 text-sm font-medium rounded-full bg-gray-100 hover:bg-gray-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
          >
            {category.replace('_', ' ')}
          </button>
        ))}
      </div>
    </div>
  );
}
export type Equipment = {
  id: string;
  name: string;
  category: 'electronics' | 'home_appliances' | 'tools' | 'sports';
  description: string;
  price_per_day: number;
  available: boolean;
  image_url: string;
};

export type User = {
  id: string;
  email: string;
  points: number;
};

export type RentalPeriod = {
  start_date: Date;
  end_date: Date;
};
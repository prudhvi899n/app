/*
  # Initial Schema Setup for Equipment Rental Platform

  1. New Tables
    - users
      - id (uuid, primary key)
      - email (text, unique)
      - points (integer)
      - created_at (timestamp)
    
    - equipment
      - id (uuid, primary key)
      - name (text)
      - category (text)
      - description (text)
      - price_per_day (numeric)
      - available (boolean)
      - image_url (text)
      - created_at (timestamp)
    
    - rentals
      - id (uuid, primary key)
      - user_id (uuid, foreign key)
      - equipment_id (uuid, foreign key)
      - start_date (timestamp)
      - end_date (timestamp)
      - total_price (numeric)
      - created_at (timestamp)

  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users
*/

-- Users Table
CREATE TABLE users (
  id uuid PRIMARY KEY DEFAULT auth.uid(),
  email text UNIQUE NOT NULL,
  points integer DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE users ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can read own data"
  ON users
  FOR SELECT
  TO authenticated
  USING (auth.uid() = id);

-- Equipment Table
CREATE TABLE equipment (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  category text NOT NULL,
  description text,
  price_per_day numeric NOT NULL,
  available boolean DEFAULT true,
  image_url text,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE equipment ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can read equipment"
  ON equipment
  FOR SELECT
  TO authenticated
  USING (true);

-- Rentals Table
CREATE TABLE rentals (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES users(id),
  equipment_id uuid REFERENCES equipment(id),
  start_date timestamptz NOT NULL,
  end_date timestamptz NOT NULL,
  total_price numeric NOT NULL,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE rentals ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can read own rentals"
  ON rentals
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create rentals"
  ON rentals
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);